# Unidad2POO
Código Python Programación Orientada a Objetos
En este repositorio encontrarás el código que se ve en las diapositivas de la Unidad 2 de Programación Orientada a Objetos.
Atentamente 
Equipo de Cátedra
Programación Orientada a Objetos
LCC-LSI-TUPWeb
Departamento de Informática
Facultad de Ciencias Exactas, Físicas y Naturales
Universidad Nacional de San Juan
